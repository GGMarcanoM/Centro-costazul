﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class Tiendas : Form
    {
        string[]ropa = {"Zara","Mango","Bershka","Pull & Bear","Stradivarius" , "Oysho","Massimo Dutti","Cortefiel","Celio","Charles & Keith","Desigual","Levis","Naf Naf","Tommy Hilfiger","Lacoste","Polo Ralph Lauren","Calvin Klein","Michael Kors","Carolina Herrero","Max Mara","Guess","Benetton","Anthony Morillo","Andrea"};
        string[]complementos = {"Parfois","Pandora","Swarovski","Tous","Aiko Sushi Bar","BoConcept","Casa Dior","Casa Emporio Armani","Casa Gianfranco Ferre","Casa Givenchy","Casa Gucci","Casa Hugo Boss","Casa Karl Lagerfeld","Casa Lanvin","Casa Loewe","Casa Louis Vuitton","Casa Max Mara","Casa Michael Kors","Casa Moschino","Casa Prada","Casa Ralph Lauren","Casa Salvatore Ferragamo","Casa Valentino","Casa Versace"};
        string[]electronicos = {"Compumundo"," EPK", "Movistar", "iPhone Store", "Microsoft Store", "Samsung Store"};
     string[]hogar={"Home Depot", "Ferretería EPA", "General Electric"};
    string[]arcade = {"Fun World", "Fun World Jr."};
    string[]foodwears = {"Calzados Andrea", "Calzados Bata", "Calzados Belice", "Calzados Capri", "Calzados D'Italia", "Calzados Ecco"," Calzados Globe", "Calzados Kiko", "Calzados Levis", "Calzados Scarpa", "Calzados Timberland", "Foot Locker","Crocs"};
    string[]deportivo= {"Nike", "Adidas", "Puma", "Reebok", "Decathlon"};
    string[]rapida={"McDonald's", "Subway", "Domino's Pizza", "Five Guys", "Gorditos", "Papa John's"," KFC", "Wendy's"};
    string[]informal = {"La Cantina", "La Cucina"," La Fuente"," La Montagne"," La Nonna"," La Taverne"," La Veneziana"," Mr. Brochette"," Pomodoro"," Renzo Ristorante"," Sushi Itto."};
    string[]Cafe={"Café Caribe", "Café La Florida", "Café La Granja", "Café Lechat", "Café Maracuya", "Café San Antonio", "Doppio Caffe"};
    string[] heladeria = { "Heladería Vía Láctea", "4D", "McDonals", "KFC" };
    string[] papeleria = {"Librería Ateneo", "Librería Mondadori"};
    string[] farmacia = {"Farmacia Latina", "Farmacia Saas", "Locatel","Farmatodo"};
    string [] peluqueria = {"Inter Imagen","JLbarbershop"};
    string [] zapatos = {"Nike", "Adidas", "Puma", "Reebok", "DecathloCalzados Andrea", "Calzados Bata", "Calzados Belice", "Calzados Capri", "Calzados D'Italia", "Calzados Ecco", "Calzados Globe", "Calzados Kiko", "Calzados Levis"," Calzados Scarpa"," Calzados Timberland"," Foot Locker", "Crocs"};
    string[] juegeteria = {"Juguetería Mundo Fantasía"};
         public Tiendas()
        {
            InitializeComponent();
        }

        private void Tiendas_Load(object sender, EventArgs e)
        {

        }
    }
}
