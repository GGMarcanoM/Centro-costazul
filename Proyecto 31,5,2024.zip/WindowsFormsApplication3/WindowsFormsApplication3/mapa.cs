﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApplication3
{
    public partial class mapa : Form
    {
        public mapa()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                
                if (textBox1.Text == "") MessageBox.Show("Tiene que colocar su nombre");
                else if (comboBox1.SelectedIndex == -1) MessageBox.Show("Tiene que seleccionar si es extranjera o nacional");
                else if (Cedula.Text == "") MessageBox.Show("Tiene que decir su cedula");
                else if (Vehiculo.SelectedIndex == -1) MessageBox.Show("Tiene que selecionar en que vehiculo vino");
                else
                {
                    TextWriter personas = new StreamWriter(@"C:\Users\USUARIO\Documents\Visual Studio 2012\Projects\WindowsFormsApplication3\WindowsFormsApplication3\bin\Debug\Registros " + comboBox1.Text + Cedula.Text+ ".txt", true);
                    personas.WriteLine("Nombre: " + textBox1.Text);
                    personas.WriteLine("C.I: " + comboBox1.Text + ": " + Cedula.Text);
                    personas.WriteLine("Hora de entrada: " + (DateTime.Now));
                    String vehiculo = Vehiculo.Text;
                    personas.WriteLine("Tipo de Vehiculo: " + Vehiculo.Text);
                    if (vehiculo.Equals("Taxi"))
                    {
                        MessageBox.Show("Registro completado");
                        this.Hide();
                        Venta buy = new Venta();
                        buy.Show();
                        personas.Close();
                    }
                    else if (vehiculo.Equals("Autobus"))
                    {
                        MessageBox.Show("Registro completado");
                        this.Hide();
                        Venta buy = new Venta();
                        buy.Show();
                        personas.Close();
                    }
                    else
                    {
                        if (Entrada.SelectedIndex == -1) MessageBox.Show("Tiene que selecionar la entrada por dentro entro");
                        //else if (Puesto.SelectedIndex == null) MessageBox.Show("Tiene que selecionar el numero del puesto donde se estaciono");
                        else if (comboBox5.SelectedIndex == -1) MessageBox.Show("Tiene que selecionar que el vehículo es prpio o de alguien más");
                        else if (textBox3.Text == "") MessageBox.Show("Tiene que ingresar la marca de auto");
                        else if (textBox2.Text == "") MessageBox.Show("Tiene que ingresar la placa del vehículo");
                        else if (textBox4.Text == "") MessageBox.Show("Tiene que ingresar el color de su vehículo");
                        else
                        {
                            personas.WriteLine("Puerta: " + Entrada.Text);
                            personas.WriteLine("No.Estacionamiento: " + Puesto.Text);
                            personas.WriteLine("De quien es el vehículo: " + comboBox5.Text);
                            personas.WriteLine("Marca de Vehiculo: " + textBox3.Text);
                            personas.WriteLine("Placa: " + textBox2.Text);
                            personas.WriteLine("Color: " + textBox4.Text);
                            personas.Close();
                            MessageBox.Show("Registro completado");
                            this.Hide();
                            Venta buy = new Venta();
                            buy.Show();

                        }
                    }

                }
            }
            catch (Exception x)
            {
                MessageBox.Show("Hubo un error " + x, "Error");
            }
            
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 principal = new Form1();
            principal.Show();
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            
        }

        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            for (int i = 1; i <= 450; i++)
            {
                Puesto.Items.Add(Convert.ToString(i ));
            }
            
        }

        

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            String vehiculo = Vehiculo.Text;
            Boolean acceso = false;
            if (vehiculo.Equals("Taxi")) acceso = false;
            else if (vehiculo.Equals("Autobus")) acceso = false;
            else acceso = true;
            Puesto.Enabled = acceso;
            Entrada.Enabled = acceso;
            comboBox5.Enabled = acceso;
            textBox3.Enabled = acceso;
            textBox2.Enabled = acceso;
            textBox4.Enabled = acceso;
   
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click_1(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }
    }
}
