﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApplication3
{
    public partial class Mercado : Form
    {
        double costo;
        public Mercado()
        {
            InitializeComponent();
        }

        private void Buy_Click(object sender, EventArgs e)
        {
            if (comprador.Text == "") MessageBox.Show("Tiene que Ingresar su nombre para el registro");
            else if (Tipocedula.SelectedIndex == -1) MessageBox.Show("Tiene que seleccionar un tu tipo de documento identificacion");
            else if (cedula.Text == "") MessageBox.Show("Tiene que ingresar el numero de su documeto de identificacion");
            else if (ListProduct.SelectedIndex == -1) MessageBox.Show("Tiene que seleccionar un producto");
            else if (cant.Text == "") MessageBox.Show("Debes ingresar la cantidad de productos que quiere");
            else if (Tipodeventa.SelectedIndex == -1) MessageBox.Show("Debe seleccionar el tipo de ompra que va a realizar");
            else if (metodopago.SelectedIndex == -1) MessageBox.Show("Tiene que seleccionar el metodo de pago");
            else
            {
                string Producto = ListProduct.Text;
                int cantidad = Convert.ToInt32(cant.Text);
                string metodo = metodopago.Text;
                double Ctotal = costo * cantidad;

                ListViewItem mostrar = new ListViewItem(comprador.Text);
                mostrar.SubItems.Add(Tipocedula.Text + " " + cedula.Text);
                mostrar.SubItems.Add(Tipodeventa.Text);
                mostrar.SubItems.Add(metodo);
                mostrar.SubItems.Add(Convert.ToString(Producto));
                mostrar.SubItems.Add(Convert.ToString(costo));
                mostrar.SubItems.Add(Convert.ToString(cantidad));
                mostrar.SubItems.Add(Convert.ToString(Ctotal));
                ListDatos.Items.Add(mostrar);

                try
                {
                    DateTime dia = DateTime.Now;
                    TextWriter compra = new StreamWriter(@"C:\Users\USUARIO\Documents\Visual Studio 2012\Projects\WindowsFormsApplication3\WindowsFormsApplication3\bin\Debug\" + Tipocedula.Text + cedula.Text + ".txt", true);
                    compra.Write("Cliente: " + comprador.Text + " /");
                    compra.Write("Producto: " + Producto + " /");
                    compra.Write("Cantidad: " + Convert.ToString(cantidad) + " /");
                    compra.Write("Tipo de Compra: " + Tipodeventa.Text + " /");
                    compra.Write("Metodo de pago: " + metodo + " /");
                    compra.Write("Costo de producto: " + Convert.ToString(costo) + " /");
                    compra.Write("Costo Total: " + Convert.ToString(Ctotal) + " /");
                    if (Producto.Equals("Botas")) compra.Write("Codigo de producto: 214589012");
                    else if (Producto.Equals("Tacones")) compra.Write("Codigo de producto: 112574569/");
                    else if (Producto.Equals("Chancletas")) compra.Write("Codigo de producto: 248959421/");
                    else if (Producto.Equals("Deportivos")) compra.Write("Codigo de producto: 1476350623/");
                    else if (Producto.Equals("Casuales")) compra.Write("Codigo de producto: 230987645/");
                    switch (dia.DayOfWeek)
                    {
                        case DayOfWeek.Monday:
                        case DayOfWeek.Tuesday:
                        case DayOfWeek.Wednesday:
                            compra.Write("Encargado: Maria/");
                            break;
                        case DayOfWeek.Thursday:
                        case DayOfWeek.Friday:
                            compra.Write("Encargado: Lucy/");
                            break;
                        case DayOfWeek.Saturday:
                        case DayOfWeek.Sunday:
                            compra.Write("Encargado: Angel/");
                            break;


                    }
                    compra.Write("fecha de compra: " + (DateTime.Now));
                    compra.Close();
                    Cancel_Click(sender, e);

                }
                catch
                { }


            }
        }

        private void ListProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            string producto = ListProduct.Text;
            if (producto.Equals("1kg  fruta")) costo = 3.45;
            else if (producto.Equals("Botella de agua")) costo = 1;
            else if (producto.Equals("Refresco 2L")) costo = 1.45;
            else if (producto.Equals("Papel higienico")) costo = 2.35;
            else if (producto.Equals("Caramelos")) costo = 0.15;
            lblCosto.Text = Convert.ToString(costo + " $");
        }

        private void Finish_Click(object sender, EventArgs e)
        {
            var busqueda = File.Exists(@"C:\Users\USUARIO\Documents\Visual Studio 2012\Projects\WindowsFormsApplication3\WindowsFormsApplication3\bin\Debug\Registros " + Tipocedula.Text + cedula.Text + ".txt");
            if (Tipodeventa.Text == "Online" || Tipodeventa.SelectedIndex == -1)
            {
                this.Hide();
                Form1 principal = new Form1();
                principal.Show();
            }
            else if (busqueda == true)
            {
                this.Hide();
                Form1 principal = new Form1();
                principal.Show();
            }
            else
            {
                this.Hide();
                mapa registro = new mapa();
                registro.Show();
            }
        }

        private void Cancel_Click(object sender, EventArgs e)
        {

        }

        private void Tipodeventa_SelectedIndexChanged(object sender, EventArgs e)
        {
            string pago = Tipodeventa.Text;
            if (pago.Equals("Persona"))
            {
                metodopago.Items.Add("Efectivo");
                metodopago.Items.Add("Tarjeta de debito");
                metodopago.Items.Add("Tarjeta de credito");
            }
            else
            {
                metodopago.Items.Add("Transferencia");
                metodopago.Items.Add("Deposito");
            }
        }

        private void Mercado_Load(object sender, EventArgs e)
        {
            lblCosto.Text = Convert.ToString(costo + " $");

        }
    }
}
    