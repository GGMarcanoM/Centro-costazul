﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class Tienda : Form
    {
        string[]ropa = {"Zara","Mango","Bershka","Pull & Bear","Stradivarius" , "Oysho","Massimo Dutti","Cortefiel","Celio","Charles & Keith","Desigual","Levis","Naf Naf","Tommy Hilfiger","Lacoste","Polo Ralph Lauren","Calvin Klein","Michael Kors","Carolina Herrero","Max Mara","Guess","Benetton","Anthony Morillo","Andrea"};
        string[]complementos = {"Parfois","Pandora","Swarovski","Tous","Aiko","BoConcept","Casa Dior","Casa Emporio Armani","Casa Gianfranco Ferre","Casa Givenchy","Casa Gucci","Casa Hugo Boss","Casa Karl Lagerfeld","Casa Lanvin","Casa Loewe","Casa Louis Vuitton","Casa Max Mara","Casa Michael Kors","Casa Moschino","Casa Prada","Casa Ralph Lauren","Casa Salvatore Ferragamo","Casa Valentino","Casa Versace"};
        string[]electronicos = {"Compumundo"," EPK", "Movistar", "iPhone Store", "Microsoft Store", "Samsung Store"};
     string[]hogar={"Home Depot", "Ferretería EPA", "General Electric"};
    string[]arcade = {"Fun World", "Fun World Jr."};
    string[]foodwears = {"Nike", "Adidas", "Puma", "Reebok","Calzados Andrea", "Calzados Bata", "Calzados Belice", "Calzados Capri", "Calzados D'Italia", "Calzados Ecco"," Calzados Globe", "Calzados Kiko", "Calzados Levis", "Calzados Scarpa", "Calzados Timberland", "Foot Locker","Crocs"};
    string[]deportivo= {"Nike", "Adidas", "Puma", "Reebok", "Decathlon"};
    string[]rapida={"McDonald's", "Subway", "Domino's Pizza", "Five Guys", "Gorditos", "Papa John's"," KFC", "Wendy's"};
    string[]informal = {"La Cantina", "La Cucina"," La Fuente"," La Montagne"," La Nonna"," La Taverne"," La Veneziana"," Mr. Brochette"," Pomodoro"," Renzo Ristorante"," Sushi Itto."};
    string[]Cafe={"Café Caribe", "Café La Florida", "Café La Granja", "Café Lechat", "Café Maracuya", "Café San Antonio", "Doppio Caffe"};
    string[] heladeria = { "Heladería Vía Láctea", "4D", "McDonals", "KFC" };
    string[] papeleria = {"Librería Ateneo", "Librería Mondadori"};
    string[] farmacia = {"Farmacia Latina", "Farmacia Saas", "Locatel","Farmatodo"};
    string [] peluqueria = {"Inter Imagen","JLbarbershop"};
    string[] juegeteria = {"Juguetería Mundo Fantasía"};
    string[] mercado = { "sigo", "sigo bodegon", "Rio" };
    string[] cine = {"cinex"};
        public Tienda()
        {
            InitializeComponent();
        }
        private void Tienda_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string tienda = comboBox1.Text;
            switch(tienda){
                case "Ropa":
                    comboBox2.Items.Clear();
                    for (int i = 0; i < ropa.Length; i++)
                    {
                        comboBox2.Items.Add(ropa[i]);
                    }
                    break;
                case "Complementos":
                    comboBox2.Items.Clear();
                    for (int i = 0; i < complementos.Length; i++)
                    {
                        comboBox2.Items.Add(complementos[i]);
                    }
                    break;
                case "Electronicos":
                    comboBox2.Items.Clear();
                    for (int i = 0; i < electronicos.Length; i++)
                    {
                        comboBox2.Items.Add(electronicos[i]);
                    }
                    break;
                case "Hogar":
                    comboBox2.Items.Clear();
                    for (int i = 0; i < hogar.Length; i++)
                    {
                        comboBox2.Items.Add(hogar[i]);
                    }
                    break;
                case "Arcade":
                    comboBox2.Items.Clear();
                    for (int i = 0; i < arcade.Length; i++)
                    {
                        comboBox2.Items.Add(arcade[i]);
                    }
                    break;
                case "Footwear":
                    comboBox2.Items.Clear();
                    for (int i = 0; i < foodwears.Length; i++)
                    {
                        comboBox2.Items.Add(foodwears[i]);
                    }
                    break;
                case "Deportivo":
                    comboBox2.Items.Clear();
                    for (int i = 0; i < deportivo.Length; i++)
                    {
                        comboBox2.Items.Add(deportivo[i]);
                    }
                    break;
                case "Comida Rapida":
                    comboBox2.Items.Clear();
                    for (int i = 0; i < rapida.Length; i++)
                    {
                        comboBox2.Items.Add(rapida[i]);
                    }
                    break;
                case "Comida Informal":
                    comboBox2.Items.Clear();
                    for (int i = 0; i < informal.Length; i++)
                    {
                        comboBox2.Items.Add(informal[i]);
                    }
                    break;
                case "Caféteria":
                    comboBox2.Items.Clear();
                    for (int i = 0; i < Cafe.Length; i++)
                    {
                        comboBox2.Items.Add(Cafe[i]);
                    }
                    break;
                case "Heladeria":
                    comboBox2.Items.Clear();
                    for (int i = 0; i < heladeria.Length; i++)
                    {
                        comboBox2.Items.Add(heladeria[i]);
                    }
                    break;
                case "Papeleria":
                    comboBox2.Items.Clear();
                    for (int i = 0; i < papeleria.Length; i++)
                    {
                        comboBox2.Items.Add(papeleria[i]);
                    }
                    break;
                case "Farmacia":
                    comboBox2.Items.Clear();
                    for (int i = 0; i < farmacia.Length; i++)
                    {
                        comboBox2.Items.Add(farmacia[i]);
                    }
                    break;
                case "Peluqueria":
                    comboBox2.Items.Clear();
                    for (int i = 0; i < peluqueria.Length; i++)
                    {
                        comboBox2.Items.Add(peluqueria[i]);
                    }
                    break;
                case "Jugueteria":
                    comboBox2.Items.Clear();
                    for (int i = 0; i < juegeteria.Length; i++)
                    {
                        comboBox2.Items.Add(juegeteria[i]);
                    }
                    break;
                case "mercado":
                    comboBox2.Items.Clear();
                    for (int i = 0; i < mercado.Length; i++)
                    {
                        comboBox2.Items.Add(mercado[i]);
                    }
                    break;
                case "cine":
                    comboBox2.Items.Clear();
                    for (int i = 0; i < cine.Length; i++)
                    {
                        comboBox2.Items.Add(cine[i]);
                    }
                    break;
            } 
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
