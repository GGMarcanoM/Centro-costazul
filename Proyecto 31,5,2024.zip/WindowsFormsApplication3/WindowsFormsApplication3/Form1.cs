﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication3
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Informacion info = new Informacion();
            info.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DateTime Now = DateTime.Now;
            
             /*switch (Now.DayOfWeek)
             {
                 case DayOfWeek.Monday:
                 case DayOfWeek.Tuesday:
                 case DayOfWeek.Wednesday:
                 case DayOfWeek.Thursday:
                 case DayOfWeek.Friday:
                 case DayOfWeek.Saturday:
                   
                     if (Now.Hour < 11 || Now.Hour >= 21) MessageBox.Show("No puedes hacer ninguna compra en el Costazul que no sea entre las 11 am - 9pm");
                     else
                     {
                         this.Hide();
                         mapa buy = new mapa();
                         buy.Show();
                     }
                     break;
                 case DayOfWeek.Sunday:
                     if (Now.Hour < 12 || Now.Hour >= 20) MessageBox.Show("No puedes hacer ninguna compra en el Costazul que no sea entre las 12 am - 8pm");
                     else
                     {
                         this.Hide();
                         mapa buy = new mapa();
                         buy.Show();
                     }
                     break;
              
                        
             }*/
            this.Hide();
          Tienda buy = new Tienda();
            buy.Show();

            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form3 edit = new Form3();
            edit.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            hora.Text = DateTime.Now.ToString("hh:mm:ss");
            Fecha.Text = DateTime.Now.ToLongDateString();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Enabled = true;
        }

       
    }
}
