﻿namespace WindowsFormsApplication3
{
    partial class Venta
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.Tipocedula = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cedula = new System.Windows.Forms.TextBox();
            this.lbelProduct = new System.Windows.Forms.Label();
            this.cant = new System.Windows.Forms.TextBox();
            this.lblCosto = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.metodopago = new System.Windows.Forms.ComboBox();
            this.ListProduct = new System.Windows.Forms.ComboBox();
            this.ListDatos = new System.Windows.Forms.ListView();
            this.Buy = new System.Windows.Forms.Button();
            this.Cancel = new System.Windows.Forms.Button();
            this.Finish = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.comprador = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.Tipodeventa = new System.Windows.Forms.ComboBox();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader3 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader4 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader5 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader6 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader7 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader8 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.Tipodeventa);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.comprador);
            this.groupBox1.Controls.Add(this.Tipocedula);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.cedula);
            this.groupBox1.Controls.Add(this.lbelProduct);
            this.groupBox1.Controls.Add(this.cant);
            this.groupBox1.Controls.Add(this.lblCosto);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.metodopago);
            this.groupBox1.Controls.Add(this.ListProduct);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(560, 180);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "groupBox1";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(415, 38);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(121, 18);
            this.label6.TabIndex = 46;
            this.label6.Text = "Costo de producto";
            // 
            // Tipocedula
            // 
            this.Tipocedula.FormattingEnabled = true;
            this.Tipocedula.Items.AddRange(new object[] {
            "V",
            "E",
            "P"});
            this.Tipocedula.Location = new System.Drawing.Point(9, 35);
            this.Tipocedula.Name = "Tipocedula";
            this.Tipocedula.Size = new System.Drawing.Size(45, 21);
            this.Tipocedula.TabIndex = 45;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(6, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(199, 18);
            this.label5.TabIndex = 44;
            this.label5.Text = "Documentos de identificación";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // cedula
            // 
            this.cedula.Location = new System.Drawing.Point(60, 36);
            this.cedula.Name = "cedula";
            this.cedula.Size = new System.Drawing.Size(128, 20);
            this.cedula.TabIndex = 43;
            // 
            // lbelProduct
            // 
            this.lbelProduct.AutoSize = true;
            this.lbelProduct.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbelProduct.Location = new System.Drawing.Point(161, 61);
            this.lbelProduct.Name = "lbelProduct";
            this.lbelProduct.Size = new System.Drawing.Size(65, 18);
            this.lbelProduct.TabIndex = 8;
            this.lbelProduct.Text = "Producto";
            // 
            // cant
            // 
            this.cant.Location = new System.Drawing.Point(163, 138);
            this.cant.Name = "cant";
            this.cant.Size = new System.Drawing.Size(100, 20);
            this.cant.TabIndex = 7;
            // 
            // lblCosto
            // 
            this.lblCosto.AutoSize = true;
            this.lblCosto.Font = new System.Drawing.Font("Modern No. 20", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCosto.Location = new System.Drawing.Point(435, 73);
            this.lblCosto.Name = "lblCosto";
            this.lblCosto.Size = new System.Drawing.Size(76, 25);
            this.lblCosto.TabIndex = 6;
            this.lblCosto.Text = "Precio";
            this.lblCosto.Click += new System.EventHandler(this.lblCosto_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 116);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(93, 18);
            this.label3.TabIndex = 5;
            this.label3.Text = "Tipo de Pago";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(160, 117);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 18);
            this.label2.TabIndex = 4;
            this.label2.Text = "Cantidad";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(6, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 18);
            this.label1.TabIndex = 3;
            // 
            // metodopago
            // 
            this.metodopago.FormattingEnabled = true;
            this.metodopago.Location = new System.Drawing.Point(6, 137);
            this.metodopago.Name = "metodopago";
            this.metodopago.Size = new System.Drawing.Size(121, 21);
            this.metodopago.TabIndex = 2;
            this.metodopago.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // ListProduct
            // 
            this.ListProduct.FormattingEnabled = true;
            this.ListProduct.Items.AddRange(new object[] {
            "Botas",
            "Chancletas",
            "Tacones",
            "Deportivos",
            "Casual"});
            this.ListProduct.Location = new System.Drawing.Point(163, 82);
            this.ListProduct.Name = "ListProduct";
            this.ListProduct.Size = new System.Drawing.Size(121, 21);
            this.ListProduct.TabIndex = 0;
            this.ListProduct.SelectedIndexChanged += new System.EventHandler(this.ListProduct_SelectedIndexChanged);
            // 
            // ListDatos
            // 
            this.ListDatos.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ListDatos.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2,
            this.columnHeader3,
            this.columnHeader4,
            this.columnHeader5,
            this.columnHeader6,
            this.columnHeader7,
            this.columnHeader8});
            this.ListDatos.GridLines = true;
            this.ListDatos.Location = new System.Drawing.Point(12, 242);
            this.ListDatos.Name = "ListDatos";
            this.ListDatos.Size = new System.Drawing.Size(560, 97);
            this.ListDatos.TabIndex = 8;
            this.ListDatos.UseCompatibleStateImageBehavior = false;
            this.ListDatos.View = System.Windows.Forms.View.Details;
            // 
            // Buy
            // 
            this.Buy.BackColor = System.Drawing.Color.Gold;
            this.Buy.Location = new System.Drawing.Point(292, 198);
            this.Buy.Name = "Buy";
            this.Buy.Size = new System.Drawing.Size(81, 38);
            this.Buy.TabIndex = 9;
            this.Buy.Text = "Comprar";
            this.Buy.UseVisualStyleBackColor = false;
            this.Buy.Click += new System.EventHandler(this.Buy_Click);
            // 
            // Cancel
            // 
            this.Cancel.BackColor = System.Drawing.Color.Gold;
            this.Cancel.Location = new System.Drawing.Point(194, 198);
            this.Cancel.Name = "Cancel";
            this.Cancel.Size = new System.Drawing.Size(81, 38);
            this.Cancel.TabIndex = 10;
            this.Cancel.Text = "Cancelar";
            this.Cancel.UseVisualStyleBackColor = false;
            this.Cancel.Click += new System.EventHandler(this.Cancel_Click);
            // 
            // Finish
            // 
            this.Finish.BackColor = System.Drawing.Color.Gold;
            this.Finish.Location = new System.Drawing.Point(494, 345);
            this.Finish.Name = "Finish";
            this.Finish.Size = new System.Drawing.Size(81, 38);
            this.Finish.TabIndex = 11;
            this.Finish.Text = "Terminar";
            this.Finish.UseVisualStyleBackColor = false;
            this.Finish.Click += new System.EventHandler(this.Finish_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(213, 14);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 18);
            this.label4.TabIndex = 14;
            this.label4.Text = "Nombre";
            // 
            // comprador
            // 
            this.comprador.Location = new System.Drawing.Point(214, 35);
            this.comprador.Name = "comprador";
            this.comprador.Size = new System.Drawing.Size(168, 20);
            this.comprador.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Modern No. 20", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(6, 60);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(111, 18);
            this.label7.TabIndex = 48;
            this.label7.Text = "Tipo de Compra";
            // 
            // Tipodeventa
            // 
            this.Tipodeventa.FormattingEnabled = true;
            this.Tipodeventa.Items.AddRange(new object[] {
            "Persona",
            "Online"});
            this.Tipodeventa.Location = new System.Drawing.Point(9, 79);
            this.Tipodeventa.Name = "Tipodeventa";
            this.Tipodeventa.Size = new System.Drawing.Size(121, 21);
            this.Tipodeventa.TabIndex = 47;
            this.Tipodeventa.SelectedIndexChanged += new System.EventHandler(this.Tipodeventa_SelectedIndexChanged);
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Cliente";
            this.columnHeader1.Width = 45;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Documetocion";
            this.columnHeader2.Width = 85;
            // 
            // columnHeader3
            // 
            this.columnHeader3.Text = "Tipo de Compra";
            this.columnHeader3.Width = 89;
            // 
            // columnHeader4
            // 
            this.columnHeader4.Text = "Tipo de pago";
            this.columnHeader4.Width = 82;
            // 
            // columnHeader5
            // 
            this.columnHeader5.Text = "Producto";
            // 
            // columnHeader6
            // 
            this.columnHeader6.Text = "Precio";
            this.columnHeader6.Width = 43;
            // 
            // columnHeader7
            // 
            this.columnHeader7.Text = "Cantidad";
            this.columnHeader7.Width = 54;
            // 
            // columnHeader8
            // 
            this.columnHeader8.Text = "Total";
            this.columnHeader8.Width = 134;
            // 
            // Venta
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.ClientSize = new System.Drawing.Size(587, 411);
            this.Controls.Add(this.Finish);
            this.Controls.Add(this.Cancel);
            this.Controls.Add(this.Buy);
            this.Controls.Add(this.ListDatos);
            this.Controls.Add(this.groupBox1);
            this.Name = "Venta";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Venta";
            this.Load += new System.EventHandler(this.Venta_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.ComboBox metodopago;
        private System.Windows.Forms.ComboBox ListProduct;
        private System.Windows.Forms.TextBox cant;
        private System.Windows.Forms.Label lblCosto;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView ListDatos;
        private System.Windows.Forms.Label lbelProduct;
        private System.Windows.Forms.Button Buy;
        private System.Windows.Forms.Button Cancel;
        private System.Windows.Forms.Button Finish;
        private System.Windows.Forms.ComboBox Tipocedula;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox cedula;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox comprador;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox Tipodeventa;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.ColumnHeader columnHeader3;
        private System.Windows.Forms.ColumnHeader columnHeader4;
        private System.Windows.Forms.ColumnHeader columnHeader5;
        private System.Windows.Forms.ColumnHeader columnHeader6;
        private System.Windows.Forms.ColumnHeader columnHeader7;
        private System.Windows.Forms.ColumnHeader columnHeader8;
    }
}