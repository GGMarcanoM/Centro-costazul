﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApplication3
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 principal = new Form1();
            principal.Show();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {   
           var busqueda = File.Exists(@"C:\Users\USUARIO\Documents\Visual Studio 2012\Projects\WindowsFormsApplication3\WindowsFormsApplication3\bin\Debug\Registros " + Tipocedula.Text + cedula.Text + ".txt");

           if (busqueda ==false)
           {
               MessageBox.Show("No hay o se han borrado esos datos de ese I.D");
           }
           else
           {
               try
               {
                   string linea = File.ReadAllText("Registros "+ Tipocedula.Text + cedula.Text + ".txt");
                   textBox1.Enabled = true;
                   textBox1.Text = linea;
               }
               catch
               {



               }



           }
            
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                File.WriteAllText(Tipocedula.Text + cedula.Text + ".txt","" + textBox1.Text);
                textBox1.Text = textBox1.Text;
   
            }
            catch
            {

            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Form1 principal = new Form1();
            principal.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                File.WriteAllText(Tipocedula.Text + cedula.Text + ".txt", "");
                textBox1.Text = " ";
            }
            catch
            {


            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                string titulo = Tipocedula.Text + cedula.Text+".txt";
                File.Delete(titulo);
            
            }
            catch
            {


            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
